library(testthat)
library(BayLum)

test_check("BayLum")
